package com.dws.challenge.exception;

public class InvalidTransferAmountException extends RuntimeException {

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public InvalidTransferAmountException(String message) {
    super(message);
  }
}
