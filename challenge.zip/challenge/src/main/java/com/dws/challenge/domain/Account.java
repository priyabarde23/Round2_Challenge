package com.dws.challenge.domain;

import java.math.BigDecimal;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Account {

  @NonNull
  @JsonProperty("accountId")
  private String accountId;

  @NonNull
  @JsonProperty("balance")
  private BigDecimal balance;
}
