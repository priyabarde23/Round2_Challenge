package com.dws.challenge.service;

import com.dws.challenge.constant.AccountConstants;
import com.dws.challenge.domain.Account;
import com.dws.challenge.exception.InsufficientAmountException;
import com.dws.challenge.exception.InvalidAccountException;
import com.dws.challenge.exception.InvalidTransferAmountException;
import com.dws.challenge.repository.AccountsRepository;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class AccountsService {

  @Getter
  private final AccountsRepository accountsRepository;
  
  @Autowired
  private NotificationService notificationService;


  @Autowired
  public AccountsService(AccountsRepository accountsRepository) {
    this.accountsRepository = accountsRepository;
  }

  public void createAccount(Account account) {
    this.accountsRepository.createAccount(account);
  }

  public Account getAccount(String accountId) {
    return this.accountsRepository.getAccount(accountId);
  }

  @Transactional
  public void transferMoney(String fromAccountId, String toAccountId, BigDecimal amount) 
  {
	  if (amount.compareTo(BigDecimal.ZERO) <= 0) {
		  throw new InvalidTransferAmountException(AccountConstants.INVALID_AMOUNT_EXCEPTION_MSG);
	  }
	  
	  Account fromAccount = accountsRepository.getAccount(fromAccountId);
	  Account toAccount = accountsRepository.getAccount(toAccountId);
	  
	  if(Objects.isNull(fromAccount) || Objects.isNull(toAccount))
		  throw new InvalidAccountException(AccountConstants.INVALID_ACCOUNT_EXCEPTION_MSG);
	  
	  Account fromAccountLock = fromAccountId.compareTo(toAccountId) < 0 ? fromAccount : toAccount;
	  Account toAccountLock = fromAccountId.compareTo(toAccountId) < 0 ? toAccount : fromAccount;

	  synchronized (fromAccountLock) {
		  synchronized (toAccountLock) {
			  if (fromAccount.getBalance().compareTo(amount) == -1) {
				  throw new InsufficientAmountException(AccountConstants.INSUFICIENT_BALANCE_MSG);
			  }

			  fromAccount.setBalance(fromAccount.getBalance().subtract(amount));
			  toAccount.setBalance(toAccount.getBalance().add(amount));

			  log.info("Updated balance saved.");
			  accountsRepository.save(fromAccount);
			  accountsRepository.save(toAccount);
			  
			  String fromMessage = AccountConstants.TRANSFERRED + amount + AccountConstants.TO_ACCOUNT + toAccount;
			  String toMessage = AccountConstants.RECEIVED + amount + AccountConstants.FROM_ACCOUNT + fromAccount;
			  
			  // Send notifications
			  notificationService.notifyAboutTransfer(fromAccountLock, fromMessage);
			  notificationService.notifyAboutTransfer(toAccountLock, toMessage);
			  log.info("Available balance in both accounts : " + fromAccountLock +" , " + toAccountLock);			  
		  }
	  }
  }

}
