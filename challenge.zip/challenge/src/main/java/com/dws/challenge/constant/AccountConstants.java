package com.dws.challenge.constant;

/**
 * Application constants.
 */
public class AccountConstants {
	
	public static final String MONEY_TRANSFER_PATH = "/moneyTransfer";
	public static final String TRANSFER_SUCCESS_MSG = "Transfer successful!";
	public static final String INVALID_AMOUNT_EXCEPTION_MSG = "Transfer amount must be greater than Zero.";
	public static final String INVALID_ACCOUNT_EXCEPTION_MSG = "Invalid account number";
	public static final String INSUFICIENT_BALANCE_MSG = "Insufficient balance to trasfer.";
	public static final String TRANSFERRED = "Transferred ";
	public static final String RECEIVED = "Received ";
	public static final String TO_ACCOUNT = " to account ";
	public static final String FROM_ACCOUNT = " from account ";
	
	
	private AccountConstants() {
    }

}
