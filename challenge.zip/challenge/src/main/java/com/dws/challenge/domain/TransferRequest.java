package com.dws.challenge.domain;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TransferRequest {
	@NonNull
	@JsonProperty("fromAccount")
	private String fromAccount;
	
	@NonNull
	@JsonProperty("toAccount")
	private String toAccount;
	
	@JsonProperty("amount")
	private BigDecimal amount;
  
}
