package com.dws.challenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ChallengeApplicationTests.class)
class ChallengeApplicationTests {

	@Test
	void contextLoads() {
	}

}
