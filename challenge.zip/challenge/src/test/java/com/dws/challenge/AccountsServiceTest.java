package com.dws.challenge;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

import java.math.BigDecimal;

import com.dws.challenge.constant.AccountConstants;
import com.dws.challenge.domain.Account;
import com.dws.challenge.exception.DuplicateAccountIdException;
import com.dws.challenge.exception.InvalidAccountException;
import com.dws.challenge.exception.InvalidTransferAmountException;
import com.dws.challenge.repository.AccountsRepository;
import com.dws.challenge.service.AccountsService;
import com.dws.challenge.service.NotificationService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class AccountsServiceTest {

	@Autowired
	private AccountsService accountsService;

	@Mock
	private AccountsRepository accountsRepository;

	@Mock
	private NotificationService notificationService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		// Reset the existing accounts before each test.
		accountsService.getAccountsRepository().clearAccounts();
	}

	@Test
	void addAccount() {
		Account account = new Account();
		account.setAccountId("Id-123");
		account.setBalance(new BigDecimal(1000));
		this.accountsService.createAccount(account);

		assertThat(this.accountsService.getAccount("Id-123")).isEqualTo(account);
	}

	@Test
	void addAccount_failsOnDuplicateId() {
		String uniqueId = "Id-" + System.currentTimeMillis();
		Account account = new Account();
		account.setAccountId(uniqueId);
		this.accountsService.createAccount(account);

		try {
			this.accountsService.createAccount(account);
			fail("Should have failed when adding duplicate account");
		} catch (DuplicateAccountIdException ex) {
			assertThat(ex.getMessage()).isEqualTo("Account id " + uniqueId + " already exists!");
		}
	}

	@Test
	public void testTransferMoney_InvalidAmount() {
		Account account1 = new Account();
		account1.setAccountId("Id-123");
		account1.setBalance(new BigDecimal(1000));
		this.accountsService.createAccount(account1);
		Account account2 = new Account();
		account2.setAccountId("Id-456");
		account2.setBalance(new BigDecimal(2000));
		this.accountsService.createAccount(account2);
		InvalidTransferAmountException exception = assertThrows(InvalidTransferAmountException.class, () -> {
			accountsService.transferMoney(account1.getAccountId(), account2.getAccountId(), BigDecimal.ZERO);
		});
		assertEquals(AccountConstants.INVALID_AMOUNT_EXCEPTION_MSG, exception.getMessage());
	}

	@Test
	public void testTransferMoney_InvalidAccount() {
		Account account1 = new Account();
		account1.setAccountId("Id-123");
		account1.setBalance(new BigDecimal(1000));
		this.accountsService.createAccount(account1);
		Account account2 = new Account();
		account2.setAccountId("Id-456");
		account2.setBalance(new BigDecimal(2000));
		this.accountsService.createAccount(account2);
		InvalidAccountException exception = assertThrows(InvalidAccountException.class, () -> {
			accountsService.transferMoney("Id-123", "", BigDecimal.TEN);
		});
		assertEquals(AccountConstants.INVALID_ACCOUNT_EXCEPTION_MSG, exception.getMessage());
	}

	@Test
	public void testTransferMoney_InsufficientBalance() {
		Account fromAccount = new Account("acc1", BigDecimal.ONE);
		Account toAccount = new Account("acc2", BigDecimal.TEN);
		this.accountsService.createAccount(fromAccount);
		this.accountsService.createAccount(toAccount);

		RuntimeException exception = assertThrows(RuntimeException.class, () -> {
			accountsService.transferMoney("acc1", "acc2", BigDecimal.TEN);
		});
		assertEquals(AccountConstants.INSUFICIENT_BALANCE_MSG, exception.getMessage());
	}

	@Test
	public void testTransferMoney_Success() {
		Account fromAccount = new Account("acc1", BigDecimal.valueOf(100));
		Account toAccount = new Account("acc2", BigDecimal.valueOf(50));
		this.accountsService.createAccount(fromAccount);
		this.accountsService.createAccount(toAccount);

		accountsService.transferMoney("acc1", "acc2", BigDecimal.valueOf(50));
		assertEquals(BigDecimal.valueOf(50), fromAccount.getBalance());
		assertEquals(BigDecimal.valueOf(100), toAccount.getBalance());
	}

}
